# Pacific Edge AI — Setup after deploying to Netlify

Three things to switch on once the site is live: **(1) deploy, (2) form email notifications, (3) Janice message tracking.**

---

## 1. Deploy the folder to Netlify

Easiest way (no Git needed):

1. Go to **app.netlify.com** → log in.
2. Click **Add new site → Deploy manually**.
3. Drag the **`pacificedge-site`** folder onto the upload area. (The folder already has `index.html` at its top level, which is what Netlify needs.)
4. Wait ~30 seconds. You'll get a live URL like `random-name.netlify.app`.
5. (Optional) **Site configuration → Change site name** to something cleaner, or add your domain `pacificedge.ai` under **Domain management**.

> To update the site later, just drag the folder onto the same site's **Deploys** tab again.

---

## 2. Forms + email notifications

The site has **two** forms already built and Netlify-ready:
- **`contact`** — the "Email Us" popup on the homepage.
- **`careers`** — the "Apply Now" application form (desktop), including the **résumé file upload**.

Netlify detects both automatically when you deploy. To get an email every time someone submits:

1. In your site, go to **Forms** (left sidebar). After the first deploy you should see **`contact`** and **`careers`** listed (they may show 0 submissions until someone uses them).
2. Go to **Site configuration → Notifications → Form submission notifications**.
3. Click **Add notification → Email notification**.
4. - **Event to listen for:** New form submission
   - **Form:** choose `careers` (and repeat for `contact`)
   - **Email to notify:** `hello@pacificedge.ai`
5. Save. Do it once for `careers` and once for `contact` (or leave Form = "Any form" to cover both).

**Test it:** open the live site, submit the contact form and an application (with a résumé). Within a minute you should get an email, and the submission (with the résumé as a download link) appears under **Forms → careers**.

> Notes: Free tier = 100 form submissions/month + limited file-upload storage — plenty to start. The résumé arrives as a downloadable file link in the submission. Forms do **not** work on `localhost`/preview — only on the deployed Netlify site.

---

## 3. Janice tracking (see what visitors type into the demo)

Right now the Janice demo logs messages on the viewer's own device only. To collect from **all** visitors into a private Google Sheet (silent — visitors never see it):

1. Go to **sheets.google.com** → new blank spreadsheet → name it "Janice Messages".
2. Menu: **Extensions → Apps Script**. Delete the sample code, paste this:

   ```javascript
   function doPost(e) {
     var lock = LockService.getScriptLock();
     try { lock.waitLock(5000); } catch (err) {}

     var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheets()[0];

     // First run only: add a bold, frozen header row
     if (sheet.getLastRow() === 0) {
       sheet.appendRow(['Date', 'Visitor', 'Customer said', 'Janice replied', 'Page']);
       sheet.getRange('A1:E1').setFontWeight('bold');
       sheet.setFrozenRows(1);
     }

     var data = {};
     try { data = JSON.parse(e.postData.contents); } catch (err) {}

     // Friendly, stable label per visitor: Visitor 1, Visitor 2, ...
     var label = 'Visitor';
     var vid = data.visitor || '';
     if (vid) {
       var props = PropertiesService.getScriptProperties();
       var seen = props.getProperty('v:' + vid);
       if (seen) { label = seen; }
       else {
         var n = Number(props.getProperty('count') || '0') + 1;
         props.setProperty('count', String(n));
         label = 'Visitor ' + n;
         props.setProperty('v:' + vid, label);
       }
     }

     sheet.appendRow([ new Date(), label, data.message || '', data.reply || '', data.page || '' ]);

     if (lock.hasLock()) lock.releaseLock();
     return ContentService.createTextOutput('ok');
   }
   ```

3. Click **Deploy → New deployment** → gear icon → **Web app**.
   - **Execute as:** Me
   - **Who has access:** **Anyone**
   - **Deploy** → approve the Google permission prompt.
4. Copy the **Web app URL** (ends in `/exec`).
5. Open **ai-employee.html**, find line ~639:
   ```javascript
   var ENDPOINT = ""; // <-- paste your Google Apps Script /exec URL here
   ```
   Paste your URL between the quotes:
   ```javascript
   var ENDPOINT = "https://script.google.com/macros/s/AKfy.../exec";
   ```
6. Re-deploy the site (drag the folder again).

From then on, **every message any visitor sends Janice appears as a new row in your Google Sheet** (date · visitor · customer said · Janice replied · page). Each browser gets a stable label like **Visitor 1 / Visitor 2**, so you can group a single person's whole conversation. You can still open the on-page viewer anytime at **ai-employee.html#insights** (or press `i` three times) for a quick look.

> Tip: send me your `/exec` URL and I'll paste it into the file for you so you don't have to touch the code.
