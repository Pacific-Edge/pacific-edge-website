# Janice demo — seeing what visitors text

The Janice demo on **ai-employee.html** now quietly records every message visitors type, so you can see what people actually ask.

## How to view the messages (works right now, no setup)

Two ways:
1. Go to **ai-employee.html#insights** (just add `#insights` to the end of the URL), **or**
2. On that page, press the **`i`** key **three times** quickly.

A panel pops up showing:
- **Most asked** — the questions people send most often
- **All messages** — every message, newest first, with a timestamp
- **Export CSV** — download them all to a spreadsheet
- **Clear** — wipe the list

### Important limitation
By itself, this only shows messages typed on **the device you're looking at** (your own phone/laptop). It's perfect for testing and for spot-checks, but it will **not** automatically gather messages from every visitor around the world. For that, do the 5-minute setup below.

---

## Collect messages from ALL visitors (free, ~5 minutes)

This sends every visitor's message to a private **Google Sheet** you own.

1. Go to **sheets.google.com** and make a new blank spreadsheet. Name it "Janice Messages".
2. In the menu: **Extensions → Apps Script**. Delete whatever code is there and paste this:

```javascript
function doPost(e) {
  var lock = LockService.getScriptLock();
  try { lock.waitLock(5000); } catch (err) {}

  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheets()[0];

  // First run only: add a bold, frozen header row
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(['Date', 'Visitor', 'Customer said', 'Janice replied', 'Page']);
    sheet.getRange('A1:E1').setFontWeight('bold');
    sheet.setFrozenRows(1);
  }

  var data = {};
  try { data = JSON.parse(e.postData.contents); } catch (err) {}

  // Friendly, stable label per visitor: Visitor 1, Visitor 2, ...
  var label = 'Visitor';
  var vid = data.visitor || '';
  if (vid) {
    var props = PropertiesService.getScriptProperties();
    var seen = props.getProperty('v:' + vid);
    if (seen) { label = seen; }
    else {
      var n = Number(props.getProperty('count') || '0') + 1;
      props.setProperty('count', String(n));
      label = 'Visitor ' + n;
      props.setProperty('v:' + vid, label);
    }
  }

  sheet.appendRow([ new Date(), label, data.message || '', data.reply || '', data.page || '' ]);

  if (lock.hasLock()) lock.releaseLock();
  return ContentService.createTextOutput('ok');
}
```

3. Click **Deploy → New deployment**. For type, choose **Web app**.
   - **Execute as:** Me
   - **Who has access:** **Anyone**
   - Click **Deploy**, approve the permissions.
4. Copy the **Web app URL** it gives you (it ends in `/exec`).
5. Open **ai-employee.html**, find this line near the bottom:

   ```javascript
   var ENDPOINT = ""; // <-- paste your Google Apps Script /exec URL here
   ```

   Paste your URL between the quotes, e.g.
   ```javascript
   var ENDPOINT = "https://script.google.com/macros/s/AKfy.../exec";
   ```
6. Save, re-deploy the site to Netlify.

That's it. From now on, **every message any visitor sends Janice shows up as a new row in your Google Sheet** — with the **date**, a stable **Visitor** label (Visitor 1, Visitor 2…), the **customer's message**, and **Janice's reply**. To group one person's whole conversation, sort the sheet by the Visitor column. The on-page `#insights` viewer still works too for quick checks (now showing Janice's reply under each message).

> **Visibility:** This is completely silent — visitors see nothing, no banner, no indicator. The viewer only opens for you (via `#insights` or pressing `i` three times). Nothing tells the visitor their messages are saved.
>
> Quick heads-up (not blocking): silently logging what people type is common for demo analytics, but if a visitor ever typed something personal it'd be stored. Keep it to the demo, don't store anything sensitive, and you're fine. Your call.
